jQuery(document).ready(function ($) {
	$('#newsticker').breakingNews(); 
	$('#newsticker3').breakingNews();
});
